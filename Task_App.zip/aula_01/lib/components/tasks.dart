import 'package:aula_01/components/difficulty.dart';
import 'package:flutter/material.dart';

class Task extends StatefulWidget {
  final String nome;
  final int dificuldade;
  final String foto;

  Task(this.nome, this.foto, this.dificuldade, {super.key});

  int level = 1;

  @override
  State<Task> createState() => _TaskState();
}

class _TaskState extends State<Task> {



  void LevelUp() {
    setState(() {
      widget.level++;
    });
  }

  bool assetOrNetwork(){
    if(widget.foto.contains('http')){
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        child: Stack(
          children: [
            Container(
              height: 130,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(5),
                color: Colors.lightBlue,),
            ),
            Column(
              children: [
                Container(
                  color: Colors.white70,
                  height: 100,

                  child: Container(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                            width: 80,
                            height: 100,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5)
                              ,
                              color: Colors.grey,
                            ),

                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(5),
                              child: assetOrNetwork()
                              ? Image.asset(
                                  widget.foto,
                                fit: BoxFit.cover,
                              )
                              : Image.network(
                                  widget.foto,
                                fit: BoxFit.cover,
                                ),
                              ),
                            ),
                        Container(
                            width: 200,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  widget.nome,
                                  style: TextStyle(
                                      fontSize: 20,
                                      overflow: TextOverflow.ellipsis),
                                ),
                                //Dificuldade
                                Difficulty(widget.dificuldade),
                              ],
                            )),


                        Container(
                          width: 90,
                          height: 90,
                          child: ElevatedButton(
                            onPressed: LevelUp,
                            child: Column(
                              children: [

                                Icon(Icons.arrow_drop_up),
                                Text("UP", style: TextStyle(fontSize: 12),),
                              ],
                            ),

                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(right: 12),
                      child: Container(
                        //Barra de progresso
                        child: LinearProgressIndicator(
                          color: Colors.white,
                          value: widget.dificuldade > 0
                              ? ((widget.level / widget.dificuldade) / 10)
                              : 1,
                        ),
                        width: 200,
                      ),
                    ),
                    Padding(padding: const EdgeInsets.only(right: 12),
                      child: Text(
                        'Nível: $widget.level',
                        style: TextStyle(color: Colors.white, fontSize: 18,
                        ),
                      ),
                    )
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}